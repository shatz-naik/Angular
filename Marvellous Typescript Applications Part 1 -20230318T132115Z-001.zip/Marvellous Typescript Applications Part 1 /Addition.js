var No1 = 10;
var No2 = 11;
var Ans = 0;
Ans = No1 + No2;
console.log("Addition is : " + Ans);
