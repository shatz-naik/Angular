
    console.log("Marvellous");
    console.log("Marvellous");
    console.log("Marvellous");
    console.log("Marvellous");
    console.log("Marvellous");

    console.log("Data by the while loop")

    var Counter : number = 0;

    while(Counter < 5)
    {
        console.log("Marvellous");
        Counter++;
    }
