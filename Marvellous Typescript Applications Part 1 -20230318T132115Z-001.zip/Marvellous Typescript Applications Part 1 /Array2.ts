
// Syntax 1
var Week1 : number[] = [560,900,320,660,220,1320,470];

// Syntax 2
var Week2 : number[];
Week2 = [560,900,320,660,220,1320,470];

// Syntax 3
var Week3 : number[] = new Array(7);
Week3 = [560,900,320,660,220,1320,470];

// Synax 4
var Batches : string[] = new Array("PPA","LB","Angular","Python","LSP");
