function Addition(No1 : number, No2 : number) : number
{
    var Ans : number = 0

    Ans = No1 + No2

    return Ans
}

var Ret : number = 0

Ret = Addition(10,11)

console.log("Addition is : "+Ret)