function Maximum(No1, No2) {
    if (No1 > No2) {
        console.log("Largest number is : " + No1);
    }
    else {
        console.log("Largest number is : " + No2);
    }
}
var A = 21;
var B = 51;
Maximum(A, B);
