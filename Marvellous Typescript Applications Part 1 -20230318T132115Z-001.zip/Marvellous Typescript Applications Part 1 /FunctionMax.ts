
function Maximum(No1 : number , No2 : number) : void
{
    if(No1 > No2)
    {
        console.log("Largest number is : "+No1)
    }
    else
    {
        console.log("Largest number is : "+No2)
    }
}

var A : number = 21
var B : number = 51

Maximum(A,B)
