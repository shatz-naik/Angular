var Week = [11, 21, 51, 101, 111];
console.log(Week[0]);
console.log(Week[1]);
console.log(Week[2]);
console.log(Week[3]);
console.log(Week[4]);
console.log("Data using loop");
var Cnt = 0;
while (Cnt < Week.length) {
    console.log(Week[Cnt]);
    Cnt++;
}
