
var Week : number[] = [11,21,51,101,111]

var Cnt = 0;






            for(Cnt = 0; Cnt < Week.length; Cnt++)
            {
                console.log(Week[Cnt])
            }