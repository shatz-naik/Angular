/*
    Application which display string on console
*/

console.log("Marvellous Infosystems Web Development")

var message = "Marvellous Infosystems Web Development" 
console.log(message)