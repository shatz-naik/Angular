var Week : number[] = [11,21,51,101,111]

var Cnt = 0;

    while(Cnt < Week.length)
    {
        console.log(Week[Cnt]);
        Cnt++;
    }