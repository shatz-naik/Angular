
var Monday : number = 560;
var Tuesday : number = 900;
var Wednesday : number = 320;
var Thursday : number = 660;
var Friday : number = 220;
var Saturday : number = 1320;
var Sunday : number = 470;



var Week : number[] = [560,900,320,660,220,1320,470];

console.log(Week[0])
console.log(Week[1])
console.log(Week[2])
console.log(Week[3])
console.log(Week[4])
console.log(Week[5])
console.log(Week[6])

console.log("Array length is"+ Week.length)