import java.io.*;
import java.util.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;

class Main
{
	public static void main(String arg[])
	{
		Scanner sobj= new Scanner(System.in);
		while(true)
		{
			System.out.println("Inside main");
			System.out.println("1 : Packing");
			System.out.println("2 : Unpacking");
			System.out.println("3 : Exit");

			String Dir,Filename;
			int choice=0;

			choice=sobj.nextInt();

			switch(choice)
			{
				case 1 :
					System.out.println("Enter directory name");
					Dir=sobj.next();

					System.out.println("Enter the file name for packing");
					Filename=sobj.next();

					Packer pobj= new Packer(Dir,Filename);
					break;

				case 2 : 
					System.out.println("Enter Packed File name");
					String name=sobj.next();
					Unpacker obj= new Unpacker(name);
					break;

				case 3 : System.out.println("Thanking you for using this application");
						System.exit(0);
					break;	

					default :
						System.out.println("Wrong choice");
						break;
			}
		}
	}
}


class Packer
{
	public FileOutputStream outstream=null;
	public Packer(String FolderName, String FileName)
	{
		try
		{
			System.out.println("Inside Packer constructor");
			File outfile= new File(FileName);
			outstream= new FileOutputStream(FileName);

			System.setProperty("user.dir",FolderName);

			TravelDirectory(FolderName);
		}
		catch(Exception obj)
		{
			System.out.println(obj);
		}
	}

	public void TravelDirectory(String path)
	{
		int counter=0;
		File directoryPath= new File(path);

		File arr[]=directoryPath.listFiles();

		for(File filename : arr)
		{
			//System.out.println(filename.getName());
			//System.out.println(filename.getAbsolutePath());

			if(filename.getName().endsWith(".txt"))
			{
				counter++;
				//System.out.println(filename.getName());
				PackFile(filename.getAbsolutePath());
			}
			System.out.println("Succesfully packed files:"+counter);

			
		}
	}

	public void PackFile(String FilePath)
	{
		//System.out.println("File name received "+FilePath);
		byte Header[]= new byte[100];
		byte Buffer[] = new byte[1024];
		int length = 0;
		int counter=0;

		FileInputStream istream = null;

		File fobj= null;
		fobj=new File(FilePath);

		String temp = FilePath+" "+fobj.length(); 

		
		// create header of 100 bytes
		for(int i= temp.length(); i<100; i++)
		{
			temp= temp+" ";
		}

		Header= temp.getBytes();
		try
		{
		// open the file for reading
			istream = new FileInputStream(FilePath);

			outstream.write(Header,0,Header.length);
			while((length = istream.read(Buffer)) > 0)
			{
				outstream.write(Buffer,0,length);
			}

			istream.close();
		}
		catch(Exception obj)
		{
			
		}
	}
}

class Unpacker
{
	public FileOutputStream outstream= null;

	public Unpacker(String src)
	{
		System.out.println("Inside unpacker");
		unpackFile(src);
	}
	public void unpackFile(String FilePath)
	{
		try
		{
			FileInputStream instream= new FileInputStream(FilePath);
			byte Header[] = new byte[100];
			int length = 0;
			int counter=0;

			while((length = instream.read(Header,0,100)) > 0)
			{
				String str= new String(Header);
				String ext= str.substring(str.lastIndexOf("\\"));
				ext=ext.substring(1);

				String words[]= ext.split("\\s");
				String name=words[0];

				int size= Integer.parseInt(words[1]);

				byte arr[]= new byte[size];
				instream.read(arr,0,size);
				System.out.println("File gets created"+name);

				FileOutputStream fout= new FileOutputStream(name);
				fout.write(arr,0,size);
				counter++;
			}

			
		
			//System.out.println(Header.toString());
		}
		catch(Exception obj)
		{

		}

	}
}

