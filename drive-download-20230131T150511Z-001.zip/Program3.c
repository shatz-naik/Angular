#include<stdio.h>

int main()
{
    int i, j, ans;

    i = 10;
    j = 11;

    ans = i + j;

    printf("Addition is : %d\n",ans);
    
    return 0;
}