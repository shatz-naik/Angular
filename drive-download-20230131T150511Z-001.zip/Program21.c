#include<stdio.h>

void Display()
{
    
    printf("Marvellous : 1\n");
    printf("Marvellous : 2\n");
    printf("Marvellous : 3\n");
    printf("Marvellous : 4\n");
    printf("Marvellous : 5\n");

}

int main()
{
    Display();

    return 0;
}