
class Program245
{
    public static void main(String arg[])
    {
        int iNo1 = 10, iNo2 = 11, iAns = 0;

        iAns = iNo1 + iNo2;

        System.out.println("Addition is : "+iAns);
    }
}