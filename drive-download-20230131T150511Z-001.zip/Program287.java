import java.util.*;

class Pattern
{
    public void Display()
    {
        // Logic
    }
}

class Program287
{
    public static void main(String a[])
    {
        Pattern pobj = new Pattern();
        Scanner sobj = new Scanner(System.in);

        pobj.Display();
    }
}