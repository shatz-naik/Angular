
class ArrayX
{
    public int Arr[];

    public ArrayX(int iSize)
    {
        Arr = new int[iSize];
    }
}

class Program258
{
    public static void main(String ar[])
    {
        ArrayX obj = new ArrayX(5);
    }
}