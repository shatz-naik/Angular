#include<iostream>
using namespace std;

int main()
{
    cout<<"Jay Ganesh..."<<"\n";

    return 0;
}

// g++ Program185.cpp -o Myexe
// Myexe
// ./Myexe