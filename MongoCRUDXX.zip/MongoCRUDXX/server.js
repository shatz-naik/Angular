const express = require("express");
const app = express();

const {MongoClient} = require("mongodb");
const URL = "mongodb://localhost:27017";    //url of mongodb

const client = new MongoClient(URL);    //client =>new object of driver

app.listen(5100,function(req,res){
    console.log("Marvellous server started successfully");

});

app.get("/",function(req,res){  
    res.send("Marvellous server is live");

})

///////////////////////////////////////////////////////////
// getConnection
//Used to connect with MONGODBSERVER-> DATABASE->COLLECTION
//
///////////////////////////////////////////////////////////

async function getConnection() //user defined
{
    let result =  await client.connect();               //1)driver connects with the dbms
   
    let db = result.db("Marvellous");                   //2)connect with the actual database(db name)
   
    return db.collection("Batches");
    

}


///////////////////////////////////////////////////////////
//readData()
//Used to connect with MONGODBSERVER ->DATABASE->COLLECTION
///////////////////////////////////////////////////////////

async function readData()
{
    let data = await getConnection();
    data = await data.find().toArray();
    console.log("Data from Marvellous database is : ");
    console.log(data);
}   


///////////////////////////////////////////////////////////
//deleteData()
//used to delete the data from the database
////////////////////////////////////////////////////////

async function deleteData()
{
    let data = await getConnection();
    let result = await data.deleteOne({"Batch":"PPA"});

    if(result.acknowledged)
    {
        console.log("Delete operation is performed successfully");
    }

}


///////////////////////////////////////////////////////////
//insertData()
//used to insert the data in the database
////////////////////////////////////////////////////////
async function insertData()
{
    let data = await getConnection();
    let result = await data.insertOne({"Batch":"PPA","Fees":18500});

    if(result.acknowledged)
    {
        console.log("Insert operation successfully performed");
    }
}


///////////////////////////////////////////////////////////
//updateData()
//used to update the data in the database
////////////////////////////////////////////////////////
async function updateData()
{
    let data = await getConnection();
    let result = await data.updateOne({"Batch":"PPA"},{$set : {"Fees":20000}});

    if(result.acknowledged)
    {
        console.log("Insert operation successfully performed");
    } 
}


///////////////////////////////////////////////////////////
//main()
// It should be considered as an entrypoint function of the program
//////////////////////////////////////////////////////////




function main() //user defined(just to get feel)
{
    //deleteData();     //D-DELETE
    updateData();       //U-UPDATE
    //insertData();     //C-CREATE
    readData();         //R-READ
}

main();     
//call to the main function as it is user defined. javascript does not have main method as inbuilt func